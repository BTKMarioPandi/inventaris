<?php
Class C_laporanuang extends CI_Controller{
    
    function __construct() {
        parent::__construct();
        $this->load->library('pdf');
    }
    
    function index(){
     function tanggal_indo($tanggal, $cetak_hari=false)
    {

    $hari= array(1 => 'senin','selasa','rabu','kamis','jumat','sabtu','minggu');
    $bulan= array(1 =>'januari','februari','maret','april','mei','juni','juli','agustus','september','oktober','november','desember' );
    $split= explode('-', $tanggal);
    $tgl_indo = $split[2].','.$bulan[ (int)$split[1] ].' '.$split[0]; 
    if ($cetak_hari) {
        # code...
        $num=date('N',strtotime($tanggal));
        return $hari[$num]. ','.$tgl_indo ;
    }
    return $tgl_indo;
    }
        $pdf = new FPDF('l','mm','A5');
        // membuat halaman baru
        $pdf->AddPage();
        // setting jenis font yang akan digunakan
        $pdf->SetFont('Arial','B',16);
        $pdf->image('img/logo.png',10,0,40);
        // mencetak string 
        $pdf->Cell(200,7,'PERGURUAN TINGGI AMIK MAHAPUTRA RIAU',0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(200,10,'LAPORAN INVETARIS BARANG DI AMIK MAHAPUTRA',0,1,'C');
        // Memberikan space kebawah agar tidak terlalu rapat
        $pdf->setlinewidth(1);
        $pdf->line(10,50,200,50);
        $pdf->Cell(10,7,'',0,1);
        $pdf->Ln(5);
        $pdf->setlinewidth(0);
        $pdf->Cell(10,15,'',0,1);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(50,6,'NAMA JENIS',1,0);
        $pdf->Cell(30,6,'NAMA BARANG',1,0);
        $pdf->Cell(50,6,'JUMLAH BARANG',1,0);
        $pdf->Cell(30,6,'HARGA BARANG',1,0);
        $pdf->Cell(28,6,'TOTAL',1,1);
        
        $pdf->SetFont('Arial','',10);
        $vwbarang = $this->db->get('vwbarang')->result();
        foreach ($vwbarang as $row){
            $pdf->Cell(50,6,$row->nm_jenis,1,0);
            $pdf->Cell(30,6,$row->nm_barang,1,0);
            $pdf->Cell(50,6,$row->jumlah,1,0);
            $pdf->Cell(30,6,$row->harga,1,0);
            $pdf->Cell(28,6,$row->total,1,1);
            
        }
        $pdf->Ln(5);
        $tgl=date('y-m-d');
        $pdf->Cell(300,6,'Pekanbaru :'.tanggal_indo($tgl,true),0,0,'C');
         $pdf->Ln(20);
        $pdf->Cell(300,6,'(....................)',0,1,'C');
        $pdf->Output();
    }
}