<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class barang extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('wadir/barang_model','barang_model');
	}

	public function index()
	{
		$data = array (
			"title"			=>	"barang",
			"subtitle"		=>	"Barang",
			"judul"			=>	"barang",
			"icon"			=>	"dashboard",	
			"breadcrumb"	=>	"barang",
			"subjudul"		=>	"Inventaris barang",
			"content"		=>	'wadir/barang/v_barang',
		);

		$data["kategori"] = $this->barang_model->get_kategori();
		$data["jenis"] = $this->barang_model->get_jenis();

		$this->load->view('wadir/index', $data);
		$this->load->view('wadir/barang/fungsi.js');
		$this->load->view('wadir/barang/v_tambah_dan_edit_barang');
	}

	public function c_tampil_barang()
	{
		$barang = $this->barang_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($barang as $items) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $items->nm_barang;
			$row[] = $items->nm_kategori;
			$row[] = $items->nm_jenis;
			$row[] = $items->jumlah;
			$row[] = $items->tgl_beli;
			$row[] = $items->harga;
			$row[] = $items->tipe;
			$row[] = $items->merek;
			$row[] = $items->spesifikasi;
			$row[] = $items->total;
            //add html for action
			$row[] = '
			
			<a class="btn btn-sm btn-warning" href="javascript:void(0)" title="Edit" onclick="edit_barang('."'".$items->kd_barang."'".')"><i class="fa fa-pencil"></i> edit</a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus_barang('."'".$items->kd_barang."'".')"><i class="fa fa-trash"></i> Delete</a>';
			$data[] = $row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->barang_model->count_all(),
			"recordsFiltered" => $this->barang_model->count_filtered(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);
	}

	public function c_tambah_barang()
	{		
		$this->_validate();
		$harga = $this->input->post('harga');

		$jlh = $this->input->post('jumlah');
	
		$total = $jlh * $harga;
	//	for($i = 0; $i <= 10000000; $i++) {
			$data = array(
				'nm_barang' => $this->input->post('nm_barang'),
				'kd_kategori' => $this->input->post('kd_kategori'),
				'kd_jenis' => $this->input->post('kd_jenis'),
				'jumlah' => $this->input->post('jumlah'),
				'tgl_beli' => $this->input->post('tgl_beli'),
				'harga' => $this->input->post('harga'),
				'tipe' => $this->input->post('tipe'),
				'merek' => $this->input->post('merek'),
				'spesifikasi' => $this->input->post('spesifikasi'),
				'total' => $total


			);
			$insert = $this->barang_model->m_simpan_barang($data);
			echo json_encode(array("status" => TRUE));
	//	}
}


		public function c_update_barang()
	{
		$this->_validate();
		$harga = $this->input->post('harga');

		$jlh = $this->input->post('jumlah');
	
		$total = $jlh * $harga;
		$data = array(		
			'kd_barang' => $this->input->post('kd_barang'),	
			'nm_barang' => $this->input->post('nm_barang'),
				'kd_kategori' => $this->input->post('kd_kategori'),
				'kd_jenis' => $this->input->post('kd_jenis'),
				'jumlah' => $this->input->post('jumlah'),
				'tgl_beli' => $this->input->post('tgl_beli'),
				'harga' => $this->input->post('harga'),
				'tipe' => $this->input->post('tipe'),
				'merek' => $this->input->post('merek'),
				'spesifikasi' => $this->input->post('spesifikasi'),
			'total' => $total
			
		);
		$this->barang_model->m_update_barang(array('kd_barang' => $this->input->post('kd_barang')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function c_update_barang_berdasarkan($id)
	{
		$data = $this->barang_model->m_update_barang_berdasarkan($id);
		echo json_encode($data);
	}

	public function c_delete_barang_berdasarkan($id) 
	{
		$this->barang_model->m_delete_barang_berdasarkan($id);
		echo json_encode(array("status" => TRUE));
		}

		private function _validate()
		{
			$data = array();
			$data['error_string'] = array();
			$data['inputerror'] = array();
			$data['status'] = TRUE;

			if($this->input->post('nm_barang') == '')
			{
				$data['inputerror'][] = 'nm_barang';
				$data['error_string'][] = 'NAMA barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			}
			if($this->input->post('kd_kategori') == '')
			{
				$data['inputerror'][] = 'kd_kategori';
				$data['error_string'][] = 'kategori barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			}
			if($this->input->post('kd_jenis') == '')
			{
				$data['inputerror'][] = 'kd_jenis';
				$data['error_string'][] = 'jenis barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			}
			if($this->input->post('jumlah') == '')
			{
				$data['inputerror'][] = 'jumlah';
				$data['error_string'][] = 'jumlah barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			}
			if($this->input->post('tgl_beli') == '')
			{
				$data['inputerror'][] = 'tgl_beli';
				$data['error_string'][] = 'Tanggal beli barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			}
			if($this->input->post('harga') == '')
			{
				$data['inputerror'][] = 'harga';
				$data['error_string'][] = 'harga barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			}


			if($data['status'] === FALSE)
			{
				echo json_encode($data);
				exit();
			}
		}

	}
