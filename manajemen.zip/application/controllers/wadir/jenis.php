<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class jenis extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('wadir/jenis_model','jenis_model');
	}

	public function index()
	{
		$data = array (
			"title"			=>	"jenis",
			"subtitle"		=>	"Barang",
			"judul"			=>	"jenis",
			"icon"			=>	"dashboard",	
			"breadcrumb"	=>	"jenis",
			"subjudul"		=>	"jenis barang",
			"content"		=>	'wadir/jenis/v_jenis',
		);

		$this->load->view('wadir/index', $data);
		$this->load->view('wadir/jenis/fungsi.js');
		$this->load->view('wadir/jenis/v_tambah_dan_edit_jenis');
	}

	public function c_tampil_jenis()
	{
		$jenis = $this->jenis_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($jenis as $items) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $items->nm_jenis;
			
            //add html for action
			$row[] = '
			<a class="btn btn-sm btn-warning" href="javascript:void(0)" title="Edit" onclick="edit_jenis('."'".$items->kd_jenis."'".')"><i class="fa fa-pencil"></i> Update</a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus_jenis('."'".$items->kd_jenis."'".')"><i class="fa fa-trash"></i> Delete</a>';
			$data[] = $row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->jenis_model->count_all(),
			"recordsFiltered" => $this->jenis_model->count_filtered(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);
	}

	public function c_tambah_jenis()
	{		
		$this->_validate();
	//	for($i = 0; $i <= 10000000; $i++) {
			$data = array(
				'nm_jenis' => $this->input->post('nm_jenis'),
			);
			$insert = $this->jenis_model->m_simpan_jenis($data);
			echo json_encode(array("status" => TRUE));
	//	}
}


		public function c_update_jenis()
	{
		$this->_validate();
		$data = array(		
			'kd_jenis' => $this->input->post('kd_jenis'),	
			'nm_jenis' => $this->input->post('nm_jenis'),
			
		);
		$this->jenis_model->m_update_jenis(array('kd_jenis' => $this->input->post('kd_jenis')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function c_update_jenis_berdasarkan($id)
	{
		$data = $this->jenis_model->m_update_jenis_berdasarkan($id);
		echo json_encode($data);
	}

	public function c_delete_jenis_berdasarkan($id) 
	{
		$this->jenis_model->m_delete_jenis_berdasarkan($id);
		echo json_encode(array("status" => TRUE));
		}

		private function _validate()
		{
			$data = array();
			$data['error_string'] = array();
			$data['inputerror'] = array();
			$data['status'] = TRUE;

			if($this->input->post('nm_jenis') == '')
			{
				$data['inputerror'][] = 'nm_jenis';
				$data['error_string'][] = 'NAMA jenis HARUS DI ISI!!';
				$data['status'] = FALSE;
			}

			if($data['status'] === FALSE)
			{
				echo json_encode($data);
				exit();
			}
		}

	}
