<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class kategori extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('petugas/kategori_model','kategori_model');
	}

	public function index()
	{
		$data = array (
			"title"			=>	"kategori",
			"subtitle"		=>	"Barang",
			"judul"			=>	"kategori",
			"icon"			=>	"dashboard",	
			"breadcrumb"	=>	"kategori",
			"subjudul"		=>	"kategori barang",
			"content"		=>	'petugas/kategori/v_kategori',
		);

		$this->load->view('petugas/index', $data);
		$this->load->view('petugas/kategori/fungsi.js');
		$this->load->view('petugas/kategori/v_tambah_dan_edit_kategori');
	}

	public function c_tampil_kategori()
	{
		$kategori = $this->kategori_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($kategori as $items) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $items->nm_kategori;
			
            //add html for action
			$row[] = '
			
			<a class="btn btn-sm btn-warning" href="javascript:void(0)" title="Edit" onclick="edit_kategori('."'".$items->kd_kategori."'".')"><i class="fa fa-pencil"></i> Update</a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus_kategori('."'".$items->kd_kategori."'".')"><i class="fa fa-trash"></i> Delete</a>';
			$data[] = $row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->kategori_model->count_all(),
			"recordsFiltered" => $this->kategori_model->count_filtered(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);
	}

	public function c_tambah_kategori()
	{		
		$this->_validate();
	//	for($i = 0; $i <= 10000000; $i++) {
			$data = array(
				'nm_kategori' => $this->input->post('nm_kategori'),
			);
			$insert = $this->kategori_model->m_simpan_kategori($data);
			echo json_encode(array("status" => TRUE));
	//	}
}


		public function c_update_kategori()
	{
		$this->_validate();
		$data = array(		
			'kd_kategori' => $this->input->post('kd_kategori'),	
			'nm_kategori' => $this->input->post('nm_kategori'),
			
		);
		$this->kategori_model->m_update_kategori(array('kd_kategori' => $this->input->post('kd_kategori')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function c_update_kategori_berdasarkan($id)
	{
		$data = $this->kategori_model->m_update_kategori_berdasarkan($id);
		echo json_encode($data);
	}

	public function c_delete_kategori_berdasarkan($id) 
	{
		$this->kategori_model->m_delete_kategori_berdasarkan($id);
		echo json_encode(array("status" => TRUE));
		}

		private function _validate()
		{
			$data = array();
			$data['error_string'] = array();
			$data['inputerror'] = array();
			$data['status'] = TRUE;

			if($this->input->post('nm_kategori') == '')
			{
				$data['inputerror'][] = 'nm_kategori';
				$data['error_string'][] = 'NAMA kategori HARUS DI ISI!!';
				$data['status'] = FALSE;
			}

			if($data['status'] === FALSE)
			{
				echo json_encode($data);
				exit();
			}
		}

	}
