<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class lokasi extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('petugas/lokasi_model','lokasi_model');
	}

	public function index()
	{
		$data = array (
			"title"			=>	"lokasi",
			"subtitle"		=>	"Barang",
			"judul"			=>	"lokasi",
			"icon"			=>	"dashboard",	
			"breadcrumb"	=>	"lokasi",
			"subjudul"		=>	"lokasi barang",
			"content"		=>	'petugas/lokasi/v_lokasi',
		);

		$this->load->view('petugas/index', $data);
		$this->load->view('petugas/lokasi/fungsi.js');
		$this->load->view('petugas/lokasi/v_tambah_dan_edit_lokasi');
	}

	public function c_tampil_lokasi()
	{
		$lokasi = $this->lokasi_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($lokasi as $items) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $items->nm_lokasi;
			
            //add html for action
			$row[] = '
			<a class="btn btn-sm btn-warning" href="javascript:void(0)" title="Edit" onclick="edit_lokasi('."'".$items->kd_lokasi."'".')"><i class="fa fa-pencil"></i> Update</a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus_lokasi('."'".$items->kd_lokasi."'".')"><i class="fa fa-trash"></i> Delete</a>';
			$data[] = $row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->lokasi_model->count_all(),
			"recordsFiltered" => $this->lokasi_model->count_filtered(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);
	}

	public function c_tambah_lokasi()
	{		
		$this->_validate();
	//	for($i = 0; $i <= 10000000; $i++) {
			$data = array(
				'nm_lokasi' => $this->input->post('nm_lokasi'),
			);
			$insert = $this->lokasi_model->m_simpan_lokasi($data);
			echo json_encode(array("status" => TRUE));
	//	}
}


		public function c_update_lokasi()
	{
		$this->_validate();
		$data = array(		
			'kd_lokasi' => $this->input->post('kd_lokasi'),	
			'nm_lokasi' => $this->input->post('nm_lokasi'),
			
		);
		$this->lokasi_model->m_update_lokasi(array('kd_lokasi' => $this->input->post('kd_lokasi')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function c_update_lokasi_berdasarkan($id)
	{
		$data = $this->lokasi_model->m_update_lokasi_berdasarkan($id);
		echo json_encode($data);
	}

	public function c_delete_lokasi_berdasarkan($id) 
	{
		$this->lokasi_model->m_delete_lokasi_berdasarkan($id);
		echo json_encode(array("status" => TRUE));
		}

		private function _validate()
		{
			$data = array();
			$data['error_string'] = array();
			$data['inputerror'] = array();
			$data['status'] = TRUE;

			if($this->input->post('nm_lokasi') == '')
			{
				$data['inputerror'][] = 'nm_lokasi';
				$data['error_string'][] = 'NAMA lokasi HARUS DI ISI!!';
				$data['status'] = FALSE;
			}

			if($data['status'] === FALSE)
			{
				echo json_encode($data);
				exit();
			}
		}

	}
