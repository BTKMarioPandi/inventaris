<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{

		$data = array (
			"title"=>"Perpustakaan",
			"subtitle"=>"Amik Mahaputra Riau",
			"judul"=>"AMIK MAHAPUTRA",
			"icon"=>"home",
			"subjudul"=>"Jl. Soebrantas No. 75 - Panam",
			"content"=>'petugas/v_home'
		);

		$this->load->view('petugas/index', $data);
	}
}
