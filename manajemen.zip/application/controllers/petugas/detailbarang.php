<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class detailbarang extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('petugas/detail_model','detail_model');
	}

	public function index()
	{
		$data = array (
			"title"			=>	"Detail barang",
			"subtitle"		=>	"Detail Barang",
			"judul"			=>	"barang",
			"icon"			=>	"dashboard",	
			"breadcrumb"	=>	" Detail barang",
			"subjudul"		=>	"detail Inventaris barang",
			"content"		=>	'petugas/detailbarang/v_detailbarang',
		);

		$data["barang"] = $this->detail_model->get_barang();
		$data["lokasi"] = $this->detail_model->get_lokasi();

		$this->load->view('petugas/index', $data);
		$this->load->view('petugas/detailbarang/fungsi.js');
		$this->load->view('petugas/detailbarang/v_tambah_dan_edit_detailbarang');
	}

	public function c_tampil_detailbarang()
	{
		$detailbarang = $this->detail_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($detailbarang as $items) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $items->nm_barang;
			$row[] = $items->tgl_memperbaiki;
			$row[] = $items->kondisi;
			$row[] = $items->nm_lokasi;
			$row[] = $items->no_pc;
            //add html for action
			$row[] = '
			<a class="btn btn-sm btn-warning" href="javascript:void(0)" title="Edit" onclick="edit_detailbarang('."'".$items->kd_detail."'".')"><i class="fa fa-pencil"></i> edit</a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus_detailbarang('."'".$items->kd_detail."'".')"><i class="fa fa-trash"></i> Delete</a>';
			$data[] = $row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->detail_model->count_all(),
			"recordsFiltered" => $this->detail_model->count_filtered(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);
	}

	public function c_tambah_detailbarang()
	{		
		$this->_validate();
	//	for($i = 0; $i <= 10000000; $i++) {
			$data = array(
				'kd_barang' => $this->input->post('kd_barang'),
				'tgl_memperbaiki' => $this->input->post('tgl_memperbaiki'),
				'kondisi' => $this->input->post('kondisi'),
				'kd_lokasi' => $this->input->post('kd_lokasi'),
				'no_pc' => $this->input->post('no_pc'),
			);
			$insert = $this->detail_model->m_simpan_detailbarang($data);
			echo json_encode(array("status" => TRUE));
	//	}
}


		public function c_update_detailbarang()
	{
		$this->_validate();
		$data = array(		
			'kd_barang' => $this->input->post('kd_barang'),
				'tgl_memperbaiki' => $this->input->post('tgl_memperbaiki'),
				'kondisi' => $this->input->post('kondisi'),
				'kd_lokasi' => $this->input->post('kd_lokasi'),
				'no_pc' => $this->input->post('no_pc'),
			
		);
		$this->detail_model->m_update_detailbarang(array('kd_detail' => $this->input->post('kd_detail')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function c_update_detailbarang_berdasarkan($id)
	{
		$data = $this->detail_model->m_update_detailbarang_berdasarkan($id);
		echo json_encode($data);
	}

	public function c_delete_detailbarang_berdasarkan($id) 
	{
		$this->detail_model->m_delete_detailbarang_berdasarkan($id);
		echo json_encode(array("status" => TRUE));
		}

		private function _validate()
		{
			$data = array();
			$data['error_string'] = array();
			$data['inputerror'] = array();
			$data['status'] = TRUE;

			if($this->input->post('kd_barang') == '')
			{
				$data['inputerror'][] = 'kd_barang';
				$data['error_string'][] = 'NAMA barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			}
			if($this->input->post('tgl_memperbaiki') == '')
			{
				$data['inputerror'][] = 'tgl_memperbaiki';
				$data['error_string'][] = 'Tanggal HARUS DI ISI!!';
				$data['status'] = FALSE;
			}
			if($this->input->post('kondisi') == '')
			{
				$data['inputerror'][] = 'kondisi';
				$data['error_string'][] = 'kondisi barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			}
			if($this->input->post('kd_lokasi') == '')
			{
				$data['inputerror'][] = 'kd_lokasi';
				$data['error_string'][] = 'Lokasi barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			
			}
			if($this->input->post('no_pc') == '')
			{
				$data['inputerror'][] = 'no_pc';
				$data['error_string'][] = 'Lokasi barang HARUS DI ISI!!';
				$data['status'] = FALSE;
			
			}

			if($data['status'] === FALSE)
			{
				echo json_encode($data);
				exit();
			}
		}

	}
