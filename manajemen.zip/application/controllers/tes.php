<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tes extends CI_Controller {


	public function __construct(){
		parent::__construct();

		$this->load->model('m_tes');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public $data = array();
	public function index()
	{
		
        $data = array (
            "title"         =>  "Anggota",
            "subtitle"      =>  "Perpustakaan",
            "judul"         =>  "Anggota",
            "icon"          =>  "dashboard",    
            "breadcrumb"    =>  "Anggota",
            "subjudul"      =>  "Kumpulan Buku Pada Library",
            "content"       =>  'form',
        );

        $this->load->view('admin/index', $data);
        $this->load->view('my.js');

    }


    public function tambah(){
      $data = array();

    if($this->input->post('submit')){ // Jika user menekan tombol Submit (Simpan) pada form
      // lakukan upload file dengan memanggil function upload yang ada di GambarModel.php
    	$upload = $this->m_tes->upload();

      if($upload['result'] == "success"){ // Jika proses upload sukses
         // Panggil function save yang ada di GambarModel.php untuk menyimpan data ke database
      	$this->m_tes->save($upload);

        redirect('tes'); // Redirect kembali ke halaman awal / halaman view data
      }else{ // Jika proses upload gagal
        $data['message'] = $upload['error']; // Ambil pesan error uploadnya untuk dikirim ke file form dan ditampilkan
    }
}

"title"         =>  "Anggota",
"subtitle"      =>  "Perpustakaan",
"judul"         =>  "Anggota",
"icon"          =>  "dashboard",    
"breadcrumb"    =>  "Anggota",
"subjudul"      =>  "Kumpulan Buku Pada Library",
"content"       =>  'form',
);

$this->load->view('admin/index', $data);
$this->load->view('my.js');

$this->load->view('form', $data);
}

}
