<?php 

class Auth extends CI_Controller{

    function index(){
        $this->load->view('templates/header');
        $this->load->view('v_login');
        $this->load->view('templates/footer');
    }

    function aksi_login(){
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $where = array(
            'username'=> $username,
            'password' => $password
        );

//artinya select table user di mana usernamenya sama dengan $username dan passwordnya sama dengan $password
        $user = $this->db->get_where('user',['username' => $username, 'password' => $password])->row_array();
        // $fotopet = $this->db->get_where('petugas',['kd_petugas' => $username, 'pw' => $password])->row_array();
        // $fotoang = $this->db->get_where('anggota',['nm_anggota' => $username, 'kd_anggota' => $password])->row_array();
        
        //jika mau ambil data yang ada di tabel petugas atau anggota seperti foto gunakan perintah yang sama seperti di atas ... ubah aja nama table nya ..contoh :
        //  $petugas = $this->db->get_where('petugas',['username' => $username, 'pw' => $password])->row_array();
        
        //jika ketemu
        if($user)
        {

            //simpan data yang ada di dalam tabel user ke sebuah session, yang berguna untuk di tampilkan ke view
            $data = [
                'username' => $user['username'],
                'password' => $user['password'],
                'level' => $user['level'],
                // 'foto' => $fotopet['gambar'],
                // 'nm_petugas' => $fotopet['nm_petugas'],
                // 'fotoa' => $fotoang['foto']
            ];

//perintah simpan ke session
            $this->session->set_userdata($data);


//jika kd_jenis sama dengan 1 ,arahkan ke admin
        
               if($user['level'] == 0)
            {
                redirect("admin");
            }
            elseif($user['level'] == 1)
            {
                redirect("petugas");
            }
            else
            {
                redirect("wadir");
            }

        }
        else
        {
            echo "Password yang anda masukkan salah !!";

        }
    }

    function logout(){
        $this->session->sess_destroy();
        redirect(base_url('auth'));
    }
}