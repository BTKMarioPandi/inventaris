<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class tampilbarang extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin/m_tampilbarang','m_tampilbarang');
	}

	public function index()
	{
		$data = array (
			"title"			=>	" Tampilan Inventaris barang",
			"subtitle"		=>	"Barang",
			"judul"			=>	"Tampilan",
			"icon"			=>	"dashboard",	
			"breadcrumb"	=>	"Tampilan barang",
			"subjudul"		=>	"Tampilan barang",
			"content"		=>	'admin/tampilbarang/v_tampilbarang',
		);

		$this->load->view('admin/index', $data);
		$this->load->view('admin/tampilbarang/fungsi.js');
	}

	public function c_tampilbarang()
	{
		$barang = $this->m_tampilbarang->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($barang as $items) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $items->nm_barang;
			$row[] = $items->jumlah;
			$row[] = $items->tgl_beli;
			$row[] = $items->harga;
			$row[] = $items->tipe;
			$row[] = $items->merek;
			$row[] = $items->spesifikasi;
			$row[] = $items->total;
			$row[] = $items->tgl_memperbaiki;
			$row[] = $items->kondisi;
			$row[] = $items->no_pc;
			$row[] = $items->nm_lokasi;
			$row[] = $items->nm_kategori;
			$row[] = $items->nm_jenis;
            //add html for action
			$data[] = $row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->m_tampilbarang->count_all(),
			"recordsFiltered" => $this->m_tampilbarang->count_filtered(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);
	}
	
		}



