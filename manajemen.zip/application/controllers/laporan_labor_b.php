<?php
Class laporan_labor_b extends CI_Controller{
    
    function __construct() {
        parent::__construct();
        $this->load->library('pdf');

    }

    
    function index(){
     function tanggal_indo($tanggal, $cetak_hari=false)
    {

    $hari= array(1 => 'senin','selasa','rabu','kamis','jumat','sabtu','minggu');
    $bulan= array(1 =>'januari','februari','maret','april','mei','juni','juli','agustus','september','oktober','november','desember' );
    $split= explode('-', $tanggal);
    $tgl_indo = $split[2].','.$bulan[ (int)$split[1] ].' '.$split[0]; 
    if ($cetak_hari) {
    	# code...
    	$num=date('N',strtotime($tanggal));
    	return $hari[$num]. ','.$tgl_indo ;
    }
    return $tgl_indo;
    }
        $pdf = new FPDF('l','mm','A3');
        // membuat halaman baru
        $pdf->AddPage();
        // setting jenis font yang akan digunakan
        $pdf->SetFont('Arial','B',16);
        $pdf->image('img/logo.png',50,0,40);
        // mencetak string 
        $pdf->Cell(300,7,'PERGURUAN TINGGI AMIK MAHAPUTRA RIAU',0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(300,7,'LAPORAN INVETARIS BARANG DI AMIK MAHAPUTRA',0,1,'C');
		$pdf->Ln(10);
        // Memberikan space kebawah agar tidak terlalu rapat
        

        $pdf->Cell(300,6,'LABOR B',0,0,'C');
        $pdf->Cell(10,7,'',0,1);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(50,6,'NAMA BARANG',1,0);
        $pdf->Cell(27,6,'JUMLAH',1,0);
        $pdf->Cell(28,6,'TANGGAL BELI',1,0);
        $pdf->Cell(25,6,'TIPE',1,0);
        $pdf->Cell(30,6,'MEREK',1,0);
        $pdf->Cell(25,6,'SPESIFIKASI',1,0);
        $pdf->Cell(20,6,'STATUS',1,0);
        $pdf->Cell(35,6,'LOKASI BARANG',1,0);
        $pdf->Cell(30,6,'KATEGORI',1,0);
        $pdf->Cell(30,6,'NO PC',1,0);
        $pdf->Cell(30,6,'JENIS',1,1);
        
        $pdf->SetFont('Arial','',10);

        $vwbarang=$this->db->get_where('vwbarang',['nm_lokasi'=>'LABOR B'])->result();
        foreach ($vwbarang as $row){
            $pdf->Cell(50,6,$row->nm_barang,1,0);
            $pdf->Cell(27,6,$row->jumlah,1,0);
            $pdf->Cell(28,6,$row->tgl_beli,1,0);
            $pdf->Cell(25,6,$row->tipe,1,0);
            $pdf->Cell(30,6,$row->merek,1,0);
            $pdf->Cell(25,6,$row->spesifikasi,1,0);
            $pdf->Cell(20,6,$row->kondisi,1,0); 
            $pdf->Cell(35,6,$row->nm_lokasi,1,0);
            $pdf->Cell(30,6,$row->nm_kategori,1,0);
            $pdf->Cell(30,6,$row->no_pc,1,0);
            $pdf->Cell(30,6,$row->nm_jenis,1,1);
          
        }
        $pdf->Ln(5);
        $tgl=date('y-m-d');
        $pdf->Cell(600,6,'Pekanbaru :'.tanggal_indo($tgl,true),0,0,'C');
        $pdf->Ln(20);
        $pdf->Cell(600,6,'(....................)',0,1,'C');
        $pdf->Output();

    }
     

}