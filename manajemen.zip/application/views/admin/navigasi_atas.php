 <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="<?php echo base_url('admin/')?>"><span class="logo-lg"><img src="<?php echo base_url('img/logoo.png') ?>" width="200px" height="45px"> <b></b></span></a>
    
    </header>
    