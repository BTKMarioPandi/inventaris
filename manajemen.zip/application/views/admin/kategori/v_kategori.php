        <div class="row">
          <div class="col-md-12">
            <div class="tile">
              <h6 class="tile-title"><p align="right">
                <button class="btn btn-success btn-sm" onclick="tambah_kategori()"><i class="fa fa-plus"></i> Tambah Kategori</button>
               <button class="btn btn-primary btn-sm" onclick="reload_table()"><i class="fa fa-refresh"></i> Reload</button>
               <a href="<?= site_url('add') ?>" class="btn btn-danger btn-sm "><span class="fa fa-print"> Print</span></a>
             </p>
           </h6>
           <hr>
           <table class="table table-hover table-bordered" id="table">
             <thead>
              <tr>
               <th>NO</th>
               <th>KATEGORI BARANG</th>
               <th style="text-align: center;">AKSI</th>
             </tr>
           </thead>
           <tbody>
           </tbody>
         </table>
       </div>
     </div>
   </div>