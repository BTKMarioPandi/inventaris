        <div class="row">
          <div class="col-md-12">
            <div class="tile">
              <h6 class="tile-title"><p align="right">
                <button class="btn btn-success btn-sm" onclick="tambah_jenis()"><i class="fa fa-plus"></i> Tambah Jenis</button>
               <button class="btn btn-primary btn-sm" onclick="reload_table()"><i class="fa fa-refresh"></i> Reload</button>
               <a href="<?= site_url('laporanpdf') ?>" class="btn btn-danger btn-sm "><span class="fa fa-print"> &nbsp;Print</span></a>
             </p>
           </h6>
           <hr>
           <table class="table table-hover table-bordered" id="table">
             <thead>
              <tr>
               <th>NO</th>
               <th>NAMA JENIS BARANG</th>
               <th style="text-align: right;">AKSI</th>
             </tr>
           </thead>
           <tbody>
           </tbody>
         </table>
       </div>
     </div>
   </div>