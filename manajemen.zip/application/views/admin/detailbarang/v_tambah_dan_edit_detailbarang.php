!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" tabindex="-1" role="dialog" data-backdrop="static" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
         <div class="modal-header bg-primary">
          <h5 class="modal-title" style="color:white"><i class="fa fa-plus"></i> Person Form</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    <div class="modal-body form"> 
        <form action="#" id="form" class="form-horizontal">
            <input type="hidden" value="" name="kd_detail"/> 
            <div class="form-group">
                    <label class="control-label col-md-4">nama barang:</label>
                    <div class="col-md-9">
                        <select name="kd_barang" id="" placeholder="kode barang" class="form-control" type="text">
                    <option value="0" name="kd_barang">-- Pilih nama --</option>
                            <?php foreach($barang as $l){ ?>
                              <option value="<?php echo $l['kd_barang']; ?>"><?php echo $l['nm_barang']; }?>   </option>
                          </select>
                        <span class="help-block"></span>
                        
                        </div>
                </div>
                <div class="form-body">
                <div class="form-group">
                    <label class="control-label col-md-4">Tanggal Memperbaiki :</label>
                    <div class="col-md-9">
                        <input name="tgl_memperbaiki" placeholder="Tanggal" class="form-control" type="date">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-body">
                <div class="form-group">
                    <label class="control-label col-md-4">kondisi barang :</label>
                    <div class="col-md-9">
                        <input name="kondisi" placeholder="kondisi" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">lokasi barang:</label>
                    <div class="col-md-9">
                        <select name="kd_lokasi" id="" placeholder="Kategori barang" class="form-control" type="text">
                    <option value="0" name="kd_lokasi">-- Pilih lokasi --</option>
                            <?php foreach($lokasi as $l){ ?>
                              <option value="<?php echo $l['kd_lokasi']; ?>"><?php echo $l['nm_lokasi']; }?>   </option>
                          </select>
                        <span class="help-block"></span>
                        
                        </div>
                </div>
<div class="form-body">
                <div class="form-group">
                    <label class="control-label col-md-4">NO PC :</label>
                    <div class="col-md-9">
                        <input name="no_pc" placeholder="no_pc" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Simpan</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
    </div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->