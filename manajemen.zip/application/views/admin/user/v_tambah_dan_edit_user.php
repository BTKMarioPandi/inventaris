!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" tabindex="-1" role="dialog" data-backdrop="static" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
         <div class="modal-header bg-primary">
          <h5 class="modal-title" style="color:white"><i class="fa fa-plus"></i> Person Form</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
            <input type="hidden" value="" name="id_user"/> 
            <div class="form-body">
                <div class="form-group">
                    <label class="control-label col-md-4">Nama User :</label>
                    <div class="col-md-9">
                        <input name="username" id="username" placeholder="Nama user" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">Password :</label>
                    <div class="col-md-9">
                        <input name="password" id="password"placeholder="*****" class="form-control" type="Password">
                        
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">Level:</label>
                    <div class="col-md-9">
                        <select name="level" placeholder="Nama user" class="form-control" type="option">
                        <option value="0">admin</option>
                         <option value="1">petugas</optio>
                        </select> 
                        <span class="help-block"></span>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Simpan</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
    </div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->