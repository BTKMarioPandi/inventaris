        <div class="row">
          <div class="col-md-12">
            <div class="tile">
              <h6 class="tile-title"><p align="right">
                <button class="btn btn-success btn-sm" onclick="tambah_user()"><i class="fa fa-plus"></i> Tambah user</button>
               <button class="btn btn-primary btn-sm" onclick="reload_table()"><i class="fa fa-refresh"></i> Reload</button>
             </p>
           </h6>
           <hr>
           <table class="table table-hover table-bordered" id="table">
             <thead>
              <tr>
               <th>NO</th>
               <th>USERNAME</th>
               <th>PASSWORD</th>
               <th>LEVEL</th>

               <th style="text-align: right;">AKSI</th>
             </tr>
           </thead>
           <tbody>
           </tbody>
         </table>
       </div>
     </div>
   </div>