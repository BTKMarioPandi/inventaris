!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" tabindex="-1" role="dialog" data-backdrop="static" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
         <div class="modal-header bg-primary">
          <h5 class="modal-title" style="color:white"><i class="fa fa-plus"></i> Person Form</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
            <input type="hidden" value="" name="kd_barang"/> 
            <div class="form-body">
                <div class="form-group">
                    <label class="control-label col-md-4">Nama barang:</label>
                    <div class="col-md-9">
                        <input name="nm_barang" placeholder="Nama barang" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">Kategori barang:</label>
                    <div class="col-md-9">
                        <select name="kd_kategori" id="" placeholder="Kategori barang" class="form-control" type="text">
                    <option value="0" name="kd_kategori">-- Pilih Kategori --</option>
                            <?php foreach($kategori as $l){ ?>
                              <option value="<?php echo $l['kd_kategori']; ?>"><?php echo $l['nm_kategori']; }?>   </option>
                          </select>
                        <span class="help-block"></span>
                        
                        </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">Jenis barang:</label>
                    <div class="col-md-9">
                        <select name="kd_jenis" id="" placeholder="jenis barang" class="form-control" type="text">
                        <option value="0" name="kd_jenis">-- Pilih jenis --</option>
                            <?php foreach($jenis as $l){ ?>
                              <option value="<?php echo $l['kd_jenis']; ?>"><?php echo $l['nm_jenis']; }?>   </option>
                          </select>
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">Jumlah barang:</label>
                    <div class="col-md-9">
                        <input name="jumlah" placeholder="jumlah barang" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">Tanggal Beli:</label>
                    <div class="col-md-9">
                        <input name="tgl_beli" placeholder="tanggal Beli" class="form-control" type="date">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">harga barang:</label>
                    <div class="col-md-9">
                        <input name="harga" placeholder="harga barang" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">tipe barang:</label>
                    <div class="col-md-9">
                        <input name="tipe" placeholder="tipe barang" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">Merek barang:</label>
                    <div class="col-md-9">
                        <input name="merek" placeholder="Merek barang" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4">Spesifikasi barang:</label>
                    <div class="col-md-9">
                        <input name="spesifikasi" placeholder="Spesifikasi" class="form-control" type="text">
                        <span class="help-block"></span>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Simpan</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
    </div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div>
