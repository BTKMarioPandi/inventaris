        <div class="row">
          <div class="col-lg-18">
            <div class="tile">
              <h6 class="tile-title"><p align="right">
                <button class="btn btn-success btn-sm" onclick="tambah_barang()"><i class="fa fa-plus"></i> Tambah barang</button>
               <button class="btn btn-primary btn-sm" onclick="reload_table()"><i class="fa fa-refresh"></i> Reload</button>
               <a href="<?= site_url('laporanpdf') ?>" class="btn btn-danger btn-sm "><span class="fa fa-print"> &nbsp;Print</span></a>
             </p>
           </h6>
           <hr>
           <table class="table table-hover table-bordered" id="table">
             <thead>
              <tr>
               <th>NO</th>
               <th>NAMA BARANG</th>
               <th>KATEGORI BARANG</th>
               <th>JENIS BARANG</th>
               <th>JUMLAH BARANG</th>
               <th> BELI BARANG</th>
               <th>HARGA BARANG</th>
               <th>TIPE BARANG</th>
               <th>MEREK BARANG</th>
               <th>SPESIFIKASI BARANG</th>
               <th>TOTAL BARANG</th>
               

               <th style="text-align: right;">AKSI</th>
             </tr>
           </thead>
           <tbody>
           </tbody>
         </table>
       </div>
     </div>
   </div>