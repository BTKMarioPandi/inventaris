        <div class="row">
          <div class="col-lg-18">
            <div class="tile">
              <h6 class="tile-title"><p align="right">
                <a href="<?= site_url('laporanpdf') ?>" class="btn btn-danger btn-sm "><span class="fa fa-print"> &nbsp;Print</span></a>
           </h6>
           <hr>
           <table class="table table-hover table-bordered" id="table">
             <thead>
              <tr>
               <th>NO</th>
               <th>NAMA BARANG</th>
               <TH>JUMLAH</TH>
               <TH>TANGGAL BELI</TH>
               <TH>HARGA</TH>
               <TH>TIPE</TH>
               <TH>MEREK</TH>
               <TH>SPESIFIKASI</TH>
               <TH>TOTAL</TH>
               <TH>TANGGAL MEMPERBAIKI</TH>
               <TH>KONDISI</TH>
               <TH>NO PC</TH>
               <TH>NAMA LOKASI</TH>
               <TH>NAMA KATEGORI</TH>
               <TH>NAMA JENIS</TH>
               
             </tr>
           </thead>
           <tbody>
           </tbody>
         </table>
       </div>
     </div>
   </div>