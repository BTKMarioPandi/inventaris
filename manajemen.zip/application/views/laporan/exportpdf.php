  <?php
    include "application/htmlpdf/fpdf.php";
    // include "../_config/config.php";


    $pdf = new FPDF('L','mm','A4');//P atau L = orientasi kertas, mm = ukuran, A4 = jenis kertas
    $pdf->AddPage();
    $pdf->AliasNbPages();
    $pdf->SetFont('Arial','B',10);//Arial = jenis huruf, B = format huruf, 10 = ukuran
    //$pdf->Cell(40,10,'',1);//40 = panjang, 10 = tinggi, 1 = tingkat ketebalan garis
    $pdf->Cell(180,10,'Data Kelas',0,0,'C'); 
    $pdf->Ln(10);//Ln = pindah baris
    $pdf->Cell(10,10,'Kode','1');
    $pdf->Cell(40,10,'Nama Barang','1');
    $pdf->Cell(40,10,'Kondisi','1');
    $pdf->Cell(40,10,'Nama Lokasi','1');
    $pdf->Cell(40,10,'NO PC','1');
    
    //pindah baris
    $pdf->Ln(10);

    $no = 1;

    $query=mysqli_query("SELECT * FROM vwlokasi
                        ORDER BY kd_detail DESC") or die (mysql_error());

    while($data = mysqlI_fetch_array($query)){

      // $pdf->Cell(10,10, $no, 1);
      $pdf->Cell(40,10, $data["kd_detail"],1);
      $pdf->Cell(40,10, $data["nm_barang"],1);
      $pdf->Cell(40,10, $data["kondis"],1);
      $pdf->Cell(40,10, $data["nm_lokasi"],1);
       $pdf->Cell(40,10, $data["no_pc"],1);
      // $pdf->Cell(40,10, $data["no_sk33"],1);
      // $pdf->Cell(40,10, $data["sk_mulai_jabatan33"],1);
      // $pdf->Cell(40,10, $data["sk_berakhir33"],1);

      $pdf->Ln(10);
      $no++;

    }




    //cetak
    $pdf->Output();

                ?>

  