<!DOCTYPE html>
<html lang="en">
<head>
  <!-- header menu-->
  <?php $this->load->view('petugas/header'); ?>
</head>
<body class="app sidebar-mini rtl">
  <!-- navigasi atas menu-->
  <?php $this->load->view('petugas/navigasi_atas'); ?>
  <!-- Sidebar menu-->
  <?php $this->load->view('petugas/sidebar'); ?>
  <!-- Content menu-->
  <main class="app-content">
    <div class="app-title">
      <div>
        <h1><i class="fa fa-<?php if(isset($icon)) { echo $icon;} else { echo "home";} ?>"></i> <?= $judul; ?></h1>
        <p><?= $subjudul; ?></p>
      </div>
      <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="#">
          <?php 
          if(isset($breadcrumb)) 
          {
            echo $breadcrumb;
          } 
          else 
          { 
            echo "Dashboard";
          } 
          ?>     
        </a></li>
      </ul>
    </div>
    <!-- content menu-->
    <?php $this->load->view($content); ?>
  </main>
  <!-- footer menu-->
  <?php $this->load->view('petugas/footer'); ?>

</body>
</html>