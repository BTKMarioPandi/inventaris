
       <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    
    <aside class="app-sidebar">
        
        <div class="app-sidebar__user">
            <img class="app-sidebar__user-avatar" src="<?php echo base_url(); ?>img/nia.png" >
            <div>
                <p class="app-sidebar__user-name">Pesta Tambunan</p>
                <p class="app-sidebar__user-designation">Web Develobmer</p>
            </div>
        </div>

    	<ul class="app-menu">

    		<li><a class="app-menu__item active" href="<?php echo site_url('petugas')?>"><i class="app-menu__icon fa fa-home" style="color:grey"></i><span class="app-menu__label">Dashboard</span></a></li>

            

    		<li class="treeview"><a class="app-menu__item" href="" data-toggle="treeview">
                <i class="app-menu__icon fa fa-book" style="color:orange"></i>
                <span class="app-menu__label">
                Inventaris Barang</span>

                <i class="treeview-indicator fa fa-angle-right"></i></a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="<?php echo site_url('petugas/barang/')?>"><i class="icon fa fa-circle-thin"></i>  Barang</a></li>
                    <li><a class="treeview-item" href="<?php echo site_url('petugas/detailbarang/')?>"><i class="icon fa fa-circle-thin"></i> Detail Barang</a></li>
                   
                    <li><a class="treeview-item" href="<?php echo site_url('petugas/jenis/')?>" rel="noopener"><i class="icon fa fa-circle-thin"></i> Jenis</a></li>
                    <li><a class="treeview-item" href="<?php echo site_url('petugas/lokasi/')?>"><i class="icon fa fa-circle-thin"></i> Lokasi Barang</a></li>
                    <li><a class="treeview-item" href="<?php echo site_url('petugas/kategori/')?>"><i class="icon fa fa-circle-thin"></i> Kategori</a></li>
                    
                </ul>
            </li>

            <li><a class="treeview-item" href="<?php echo site_url('petugas/tampilbarang/')?>"><i class="icon fa fa-user"></i> tampil barang</a></li>
                    

            <li><a class="app-menu__item" href="<?php echo site_url('petugas/user/')?>"><i class="app-menu__icon fa fa-users" style="color:red"></i><span class="app-menu__label">User</span></a></li>


            <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-file-text" style="color:blue"></i><span class="app-menu__label">Laporan</span><i class="treeview-indicator fa fa-angle-right"></i></a>
               <ul class="treeview-menu">
                <li><a class="treeview-item" href="<?= base_url(); ?>laporanpdf"><i class="icon fa fa-circle-thin"></i> barang</a></li>
                <li><a class="treeview-item" href="<?= base_url(); ?>Laporan_labor_b"><i class="icon fa fa-circle-thin"></i> Labor B</a></li>
                <li><a class="treeview-item" href="<?= base_url(); ?>c_laporanuang"><i class="icon fa fa-circle-thin"></i> keuangan</a></li>
                <li><a class="treeview-item" href="<?= base_url(); ?>laporan_labor_a"><i class="icon fa fa-circle-thin"></i> labor a</a></li>
       </ul>
   </li>
<li><a class="treeview-item" href="<?php echo site_url('auth/logout')?>"><i class="fa fa-sign-out"></i> logout</a></li>
        </ul>
    </aside>

